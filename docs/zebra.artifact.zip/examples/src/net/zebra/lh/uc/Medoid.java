/**
 * 
 */
package net.zebra.lh.uc;

/**
 * @author Loc Nguyen
 *
 */
public class Medoid extends Vector {

	
	/**
	 * 
	 * @param array
	 */
	public Medoid(double... array) {
		super(array);
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * 
	 * @param size
	 * @param initValue
	 */
	public Medoid(int size, double initValue) {
		super(size, initValue);
		// TODO Auto-generated constructor stub
	}

	
	/**
	 * 
	 * @param size
	 */
	public Medoid(int size) {
		super(size);
		// TODO Auto-generated constructor stub
	}


	/**
	 * 
	 * @param vector
	 */
	public Medoid(Vector vector) {
		super(vector);
		// TODO Auto-generated constructor stub
	}

}
