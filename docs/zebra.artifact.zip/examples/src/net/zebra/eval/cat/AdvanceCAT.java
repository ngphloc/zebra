package net.zebra.eval.cat;

/**
 * 
 * @author Loc Nguyen
 *
 */
public class AdvanceCAT {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}


